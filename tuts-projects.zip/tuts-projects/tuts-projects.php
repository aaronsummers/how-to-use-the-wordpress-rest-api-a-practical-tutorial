<?php
/*
    Plugin Name: Tutorials
    Plugin URI: http://www.enovathemes.com
    Description: Amazing Tutorials
    Author: Enovathemes
    Version: 1.0
    Author URI: http://enovathemes.com
*/
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

function envato_tutorial() {
	
	$labels = array(
		'name'               => esc_html__('Tutorials', 'envato'),
		'singular_name'      => esc_html__('Tutorial', 'envato'),
		'add_new'            => esc_html__('Add new', 'envato'),
		'add_new_item'       => esc_html__('Add new tutorial', 'envato'),
		'edit_item'          => esc_html__('Edit tutorial', 'envato'),
		'new_item'           => esc_html__('New tutorial', 'envato'),
		'all_items'          => esc_html__('All tutorials', 'envato'),
		'view_item'          => esc_html__('View tutorial', 'envato'),
		'search_items'       => esc_html__('Search tutorials', 'envato'),
		'not_found'          => esc_html__('No tutorials found', 'envato'),
		'not_found_in_trash' => esc_html__('No tutorials found in trash', 'envato'), 
		'parent_item_colon'  => '',
		'menu_name'          => esc_html__('Tutorials', 'envato')
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true, 
		'show_in_menu'       => true, 
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'tutorial','with_front' => false ),
		'capability_type'    => 'post',
		'has_archive'        => true, 
		'hierarchical'       => false,
		'menu_position'      => 20,
		'menu_icon'          => 'dashicons-portfolio',
		'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt'),
		'show_in_rest'       	=> true,
		'rest_controller_class' => 'WP_REST_Posts_Controller',
		'rest_base'             => 'tutorial',
	);

	register_post_type( 'tutorial', $args );

	register_taxonomy('tutorial-category', 'tutorial', array(
		'hierarchical' => true,
		'labels' => array(
			'name' 				=> esc_html__( 'Category', 'envato' ),
			'singular_name' 	=> esc_html__( 'Category', 'envato' ),
			'search_items' 		=> esc_html__( 'Search category', 'envato' ),
			'all_items' 		=> esc_html__( 'All categories', 'envato' ),
			'parent_item' 		=> esc_html__( 'Parent category', 'envato' ),
			'parent_item_colon' => esc_html__( 'Parent category', 'envato' ),
			'edit_item' 		=> esc_html__( 'Edit category', 'envato' ),
			'update_item' 		=> esc_html__( 'Update category', 'envato' ),
			'add_new_item' 		=> esc_html__( 'Add new category', 'envato' ),
			'new_item_name' 	=> esc_html__( 'New category', 'envato' ),
			'menu_name' 		=> esc_html__( 'Categories', 'envato' ),
		),
		'rewrite' => array(
			'slug' 		   => 'tutorial-category',
			'with_front'   => true,
			'hierarchical' => true
		),
		'show_in_nav_menus' => true,
		'show_tagcloud'     => true,
		'show_admin_column' => true,
		'show_in_rest'       	=> true,
		'rest_controller_class' => 'WP_REST_Terms_Controller',
		'rest_base'             => 'tutorial_category',
	));

	register_taxonomy('tutorial-tag', 'tutorial', array(
		'hierarchical' => false,
		'labels' => array(
			'name' 				=> esc_html__( 'Tutorials tags', 'envato' ),
			'singular_name' 	=> esc_html__( 'Tutorials tag', 'envato' ),
			'search_items' 		=> esc_html__( 'Search tutorial tags', 'envato' ),
			'all_items' 		=> esc_html__( 'All tutorial tags', 'envato' ),
			'parent_item' 		=> esc_html__( 'Parent tutorial tags', 'envato' ),
			'parent_item_colon' => esc_html__( 'Parent tutorial tag:', 'envato' ),
			'edit_item' 		=> esc_html__( 'Edit tutorial tag', 'envato' ),
			'update_item' 		=> esc_html__( 'Update tutorial tag', 'envato' ),
			'add_new_item'	    => esc_html__( 'Add new tutorial tag', 'envato' ),
			'new_item_name' 	=> esc_html__( 'New tutorial tag', 'envato' ),
			'menu_name' 		=> esc_html__( 'Tags', 'envato' ),
		),
		'rewrite' 		   => array(
			'slug' 		   => 'tutorial-tag',
			'with_front'   => true,
			'hierarchical' => false
		),
		'show_in_rest'       	=> true,
		'rest_controller_class' => 'WP_REST_Terms_Controller',
		'rest_base'             => 'tutorial_tag',
	));
}

add_action( 'init', 'envato_tutorial' );

function envato_register_rest_fields(){

    register_rest_field('tutorial',
        'tutorial_category_attr',
        array(
            'get_callback'    => 'envato_tutorial_categories',
            'update_callback' => null,
            'schema'          => null
        )
    );

    register_rest_field('tutorial',
        'tutorial_tag_attr',
        array(
            'get_callback'    => 'envato_tutorial_tags',
            'update_callback' => null,
            'schema'          => null
        )
    );

    register_rest_field('tutorial',
        'tutorial_image_src',
        array(
            'get_callback'    => 'envato_tutorial_image',
            'update_callback' => null,
            'schema'          => null
        )
    );

}
add_action('rest_api_init','envato_register_rest_fields');

function envato_tutorial_categories($object,$field_name,$request){

    $terms_result = array();

    $terms =  wp_get_post_terms( $object['id'], 'tutorial-category');

    foreach ($terms as $term) {
    	$terms_result[$term->term_id] = array($term->name,get_term_link($term->term_id));
    }

    return $terms_result;
}

function envato_tutorial_tags($object,$field_name,$request){

    $terms_result = array();

    $terms =  wp_get_post_terms( $object['id'], 'tutorial-tag');

    foreach ($terms as $term) {
    	$terms_result[$term->term_id] = array($term->name,get_term_link($term->term_id));
    }

    return $terms_result;
}

function envato_tutorial_image($object,$field_name,$request){

    $img = wp_get_attachment_image_src($object['featured_media'],'full');
    
    return $img[0];
}

function envato_styles_scripts(){
	wp_enqueue_style( 'tuts', plugins_url('/css/tuts.css', __FILE__ ));
	wp_register_script( 'tuts', plugins_url('/js/tuts.js', __FILE__ ), array('jquery'), '', true);

	wp_localize_script( 
	    'tuts', 
	    'tuts_opt', 
	    array('jsonUrl' => rest_url('wp/v2/tutorial'))
	);

}
add_action( 'wp_enqueue_scripts', 'envato_styles_scripts' );

function envato_tutorial_shortcode_callback($atts, $content = null) {
	extract(shortcode_atts(
		array(
			'layout'     => 'grid', // grid / list
			'per_page'   => '3', 	// int number
			'start_cat'  => '', 	// starting category ID
		), $atts)
	);

	global $post;

	$query_options = array(
		'post_type'           => 'tutorial',
		'post_status'         => 'publish',
		'ignore_sticky_posts' => 1,
		'orderby'             => 'date',
		'order'               => 'DESC',
		'posts_per_page' 	  => absint($per_page) 
	);

	if (isset($start_cat) & !empty($start_cat)) {

		$tax_query_array = array(
			'tax_query' => array(
			array(
				'taxonomy' => 'tutorial-category',
				'field'    => 'ID',
				'terms'    => $start_cat,
				'operator' => 'IN'
			))
		);

		$query_options = array_merge($query_options,$tax_query_array);
	}

	$tuts = new WP_Query($query_options);

	if($tuts->have_posts()){

		wp_enqueue_script('tuts');

		$output = '';
		$class  = array();

		$class[] = 'recent-tuts';
		$class[] = esc_attr($layout);

		$output .= '<div class="recent-tuts-wrapper">';

			$args = array(
                'orderby'           => 'name', 
                'order'             => 'ASC',
                'fields'            => 'all', 
                'child_of'          => 0, 
                'parent'            => 0,
                'hide_empty'        => true, 
                'hierarchical'      => false, 
                'pad_counts'        => false, 
            );

			$terms = get_terms('tutorial-category',$args);


			if (count($terms) != 0){
				$output .= '<div class="term-filter" data-per-page="'.absint($per_page).'">';

					if (empty($start_cat)) {
                        $output .= '<a href="'.esc_url(get_post_type_archive_link('tutorial')).'" class="active">'.esc_html__('All','envato').'</a>';
					}

					foreach($terms as $term){

                        $term_class = (isset($start_cat) && !empty($start_cat) && $start_cat == $term->term_id) ? $term->slug.' active' : $term->slug;
                        $term_data  = array();

                        $term_data[] = 'data-filter="'.$term->slug.'"';
                        $term_data[] = 'data-filter-id="'.$term->term_id.'"';

                        $output .= '<a href="'.esc_url(get_term_link($term->term_id, 'tutorial-category')).'" class="'.esc_attr($term_class).'" '.implode(' ', $term_data).'>'.$term->name.'</a>';
                    }

				$output .= '</div>';
			}

			$output .= '<ul class="'.implode(' ', $class).'">';
				while ($tuts->have_posts() ) {
					$tuts->the_post();

					$IMAGE = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full', false);

					$output .= '<li>';

						$output .= '<img src="'.esc_url($IMAGE[0]).'" alt="'.esc_attr(get_the_title()).'" />';

						$output .='<div class="tutorial-content">';

							$output .='<div class="tutorial-category">';
		                        $output .= get_the_term_list( get_the_ID(), 'tutorial-category', '', ', ', '' );
		                    $output .='</div>';

		                    if ( '' != get_the_title() ){
		                        $output .='<h4 class="tutorial-title entry-title">';
		                            $output .= '<a href="'.get_the_permalink().'" title="'.get_the_title().'" rel="bookmark">';
		                                $output .= get_the_title();
		                            $output .= '</a>';
		                        $output .='</h4>';
		                    }

		                    if ( '' != get_the_excerpt() && $layout == 'grid'){
		                        $output .='<div class="tutorial-excerpt">';
		                                $output .= get_the_excerpt();
		                        $output .='</div>';
		                    }

		                    $output .='<div class="tutorial-tag">';
		                        $output .= get_the_term_list( get_the_ID(), 'tutorial-tag', '', ' ', '' );
		                    $output .='</div>';

	                    $output .='</div>';

					$output .= '</li>';

				}
				wp_reset_postdata();
			$output .= '</ul>';

		$output .= '</div>';

		return $output;
	}
}
add_shortcode('tuts', 'envato_tutorial_shortcode_callback');

?>